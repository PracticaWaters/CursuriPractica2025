﻿using InventoryApp.Models;

namespace InventoryApp.DataManagement
{
    public class InventoryItemDataOps
    {
        private InventoryDbContext dbContext;

        public InventoryItemDataOps()
        {
            dbContext = new InventoryDbContext();
        }

        public InventoryItems[] GetInventoryItems()
        {
            return dbContext.inventoryItems.ToArray();
        }

        public void AddInventoryItem(InventoryItems item)
        {
            try
            {
                dbContext.inventoryItems.Add(item);
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateInventoryItem(InventoryItems item)
        {
            try
            {
                dbContext.inventoryItems.Update(item);
                dbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public InventoryItems? GetInventoryItemById(int id)
        {
            return dbContext.inventoryItems.Where(x=> x.Id == id).FirstOrDefault();
        }
    }
}
