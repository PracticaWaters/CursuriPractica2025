﻿using InventoryApp.Models;
using Microsoft.EntityFrameworkCore;

namespace InventoryApp.DataManagement
{
    public class InventoryDbContext : DbContext
    {
        public DbSet<InventoryItems> inventoryItems {  get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\mssqllocaldb;Database=InventoryItems5;Trusted_Connection=True;MultipleActiveResultSets=true");
        }
    }
}
