﻿using InventoryApp.DataManagement;
using InventoryApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryApp.Controllers
{
    [ApiController]
    [Route("api/inventory/item/")]
    public class InventoryItemController : Controller
    {
        private readonly InventoryItemDataOps inventoryItemDataOps;

        public InventoryItemController()
        {
            inventoryItemDataOps = new InventoryItemDataOps();
        }

        [HttpGet]
        public ActionResult<InventoryItems> GetInventoryItems()
        {
            try
            {
                var inventoryItems = inventoryItemDataOps.GetInventoryItems();
                return Ok(inventoryItems);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPost]
        public ActionResult AddInventoryItem(InventoryItems inventoryItem)
        {
            inventoryItemDataOps.AddInventoryItem(inventoryItem);
            return Ok();
        }

        [HttpPut]
        public ActionResult UpdateInventoryItems(InventoryItems inventoryItems)
        {
            try
            {
                inventoryItemDataOps.UpdateInventoryItem(inventoryItems);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("{id}")]

        public ActionResult<InventoryItems> GetInventoryItem(int id)
        {
            try
            {
                var inventoryItem = inventoryItemDataOps.GetInventoryItemById(id);
                return Ok(inventoryItem);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
    }
}
