export interface ContactData {
  info: string;
  phone: string;
  openDays: string;
  timeSlot: string;
  address: string;
}
